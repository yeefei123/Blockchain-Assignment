
export function Footer() {
    return (
        <>
            <div className="footer-dark">
                
            </div>
        </>
    )
}