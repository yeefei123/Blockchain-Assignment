"use client";
import { FormContext } from "@/context/FormContext";
import { ethers } from "ethers";
import { useContext, useState } from "react";
import Crowdfunding from "../../abi/Crowdfunding.json";

export default function SummaryPage() {
  const { campaignData, milestonesData } = useContext(FormContext);
  const [isLoading, setLoading] = useState(false);

  const handleSubmit = async () => {
    const confirmed = window.confirm(
      "Please check the campaign details carefully before submitting your campaign."
    );

    if (confirmed) {
      setLoading(true);

      // Check if MetaMask is installed
      if (!window.ethereum) {
        alert("Please install MetaMask");
        setLoading(false);
        return;
      }

      try {
        // Request account access
        await window.ethereum.request({ method: "eth_requestAccounts" });

        // Initialize ethers.js
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();

        const contractAddress =
          process.env.NEXT_PUBLIC_CROWDFUNDING_CONTRACT_ADDRESS;

        if (!contractAddress) {
          console.error("Crowdfunding contract address is not defined.");
          setLoading(false);
          return;
        }

        const contract = new ethers.Contract(
          contractAddress,
          Crowdfunding.abi,
          signer
        );

        const formattedMilestonesData = milestonesData.map(
          (milestone, index) => {
            if (!milestone.amount) {
              throw new Error(`Milestone ${index + 1} amount is invalid.`);
            }
            return {
              id: "0",
              campaignId: "0",
              milestonetitle: milestone.title,
              milestonedescription: milestone.description,
              targetAmt: ethers.utils.parseUnits(milestone.amount, "ether"), // Convert to wei
              startDate: Math.floor(
                new Date(milestone.startDate).getTime() / 1000
              ), // Convert to UNIX timestamp
              endDate: Math.floor(new Date(milestone.endDate).getTime() / 1000), // Convert to UNIX timestamp
            };
          }
        );
        console.log("Formatted Milestones Data:", formattedMilestonesData);
        // Call the contract function with all required parameters
        const createCampaignTx = await contract.createCampaign(
          campaignData.title,
          campaignData.desc,
          parseInt(campaignData.milestones, 10),
          campaignData.images,
          formattedMilestonesData
        );

        // Wait for the transaction to be mined
        await createCampaignTx.wait();

        alert("Campaign created successfully!");
      } catch (error) {
        console.error("Error creating campaign:", error);
        alert("Failed to create campaign. Please try again.");
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="flex flex-col items-center min-h-screen">
      <h1 className="text-4xl font-bold mb-6 text-black">Summary</h1>

      {/* Campaign Details */}
      <div className="w-3/4 bg-black text-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <h2 className="text-2xl font-bold mb-4">Campaign Details</h2>
        <p>
          <strong>Title:</strong> {campaignData.title}
        </p>
        <p>
          <strong>Description:</strong> {campaignData.desc}
        </p>
        <p>
          <strong>Milestones:</strong> {campaignData.milestones}
        </p>
        <p>
          <strong>Images:</strong> {campaignData.images}
        </p>
      </div>

      {/* Milestones Details */}
      <div className="w-3/4 bg-black text-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <h2 className="text-2xl font-bold mb-4">Milestones Details</h2>
        {milestonesData.map((milestone, index) => (
          <div key={index} className="mb-4">
            <p>
              <strong>Title:</strong> {milestone.title}
            </p>
            <p>
              <strong>Description:</strong> {milestone.description}
            </p>
            <p>
              <strong>Amount:</strong> {milestone.amount}
            </p>
            <p>
              <strong>Start Date:</strong> {milestone.startDate}
            </p>
            <p>
              <strong>End Date:</strong> {milestone.endDate}
            </p>
          </div>
        ))}
      </div>

      <button
        type="button"
        onClick={handleSubmit}
        className="bg-blue-500 mb-5 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
      >
        Submit
      </button>
    </div>
  );
}
